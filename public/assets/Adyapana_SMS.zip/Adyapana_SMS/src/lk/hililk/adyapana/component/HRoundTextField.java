package lk.hililk.adyapana.component;

import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.JTextField;

public class HRoundTextField  extends JTextField{

    public HRoundTextField() {
        init();
    }
    
    private void init(){
        this.putClientProperty(FlatClientProperties.STYLE, "arc:15;" + "margin:0,10,0,10"); //TOP, LEFT, BOTTOM, RIGHT
    }
    
}
