/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package lk.hililk.adyapana.panel;

import com.formdev.flatlaf.FlatClientProperties;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import lk.hililk.adyapana.connection.MySQL;
import lk.hililk.adyapana.gui.AdminDashboard;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import lk.hililk.adyapana.gui.student;
import lk.hililk.adyapana.gui.teacher;
import lk.hililk.adyapana.gui.teacher2;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import lk.hililk.adyapana.gui.teacher4;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRTableModelDataSource;
import net.sf.jasperreports.view.JasperViewer;
import raven.toast.Notifications;

/**
 *
 * @author Hirusha
 */
public class addPayments extends javax.swing.JPanel {

    HashMap<String, String> SubjectMap = new HashMap<>();

    /**
     * Creates new form addPayments
     */
    public addPayments() {
        initComponents();
        init();
        loadData("");
        loadData1("");
        loadSubejct();
        loadMonth();
        loadTSubjects();
        loadName();
    }
    
         private void loadName(){
        String email = AdminDashboard.aEmail;
        try {
            ResultSet result = MySQL.search("SELECT * FROM `admin` WHERE `email`='"+email+"'");
            if(result.next()){
                name.setText(result.getString("first_name")+" "+result.getString("last_name"));
                System.out.println(result.getString("first_name")+" "+result.getString("last_name"));
            }
        } catch (SQLException e) {
            AdminDashboard.logger.warning(e.getMessage());
        }
    }

    private void init() {
        search.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Search By Invoice No Or Student's Email Or Teacher's Email");
        search.putClientProperty(FlatClientProperties.TEXT_FIELD_LEADING_ICON, new ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/search (2).png")));
        search.putClientProperty(FlatClientProperties.STYLE, "arc:15;" + "margin:5,20,5,20");
        studentInput.setEnabled(false);
        studentLabel.setEnabled(false);
        teacherInput.setEnabled(false);
        teacherLabel.setEnabled(false);
        studentInput.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Please select a student.");
        studentLabel.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Student Email.");
        teacherInput.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Please select a teacher.");
        teacherLabel.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Teacher Email.");

        String id = String.valueOf(System.currentTimeMillis());
        invoiceInput.setText(id);
        invoiceInput.setEditable(false);
        String id1 = String.valueOf(System.currentTimeMillis());
        invoiceInput1.setText(id1);
        invoiceInput1.setEditable(false);
        payInput.setText("00.0");
    }

    private void loadData(String searchtxt) {

        if (searchtxt.equals("")) {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `student_invoice` INNER JOIN `teacher` ON `teacher`.`id`=`student_invoice`.`teacher_id` "
                        + "INNER JOIN `subject` ON `subject`.`id`=`student_invoice`.`subject_id` INNER JOIN `student` ON `student`.`id`=`student_invoice`.`student_id`"
                        + "INNER JOIN `month` ON `month`.`month_id`=`student_invoice`.`month_month_id`");
                DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> paymentList = new Vector();
                    count++;
                    paymentList.add(String.valueOf(count));
                    paymentList.add(String.valueOf(result.getString("invoice_id")));
                    paymentList.add(String.valueOf(result.getString("paid_amount")));
                    paymentList.add(String.valueOf(result.getString("paid_date")));
                    paymentList.add(String.valueOf(result.getString("student.email")));
                    paymentList.add(String.valueOf(result.getString("student.first_name") + " " + result.getString("student.last_name")));
                    paymentList.add(String.valueOf(result.getString("teacher.email")));
                    paymentList.add(String.valueOf(result.getString("teacher.first_name") + " " + result.getString("teacher.last_name")));
                    paymentList.add(String.valueOf(result.getString("subject.name")));
                    paymentList.add(String.valueOf(result.getString("month")));
                    tableModel.addRow(paymentList);
                }
            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        } else {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `student_invoice` INNER JOIN `teacher` ON `teacher`.`id`=`student_invoice`.`teacher_id` "
                        + "INNER JOIN `subject` ON `subject`.`id`=`student_invoice`.`subject_id` INNER JOIN `student` ON `student`.`id`=`student_invoice`.`student_id`"
                        + "INNER JOIN `month` ON `month`.`month_id`=`student_invoice`.`month_month_id` WHERE `invoice_id`LIKE'%" + searchtxt + "%' OR `student`.`email`LIKE'%" + searchtxt + "%'");
                DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> paymentList = new Vector();
                    count++;
                    paymentList.add(String.valueOf(count));
                    paymentList.add(String.valueOf(result.getString("invoice_id")));
                    paymentList.add(String.valueOf(result.getString("paid_amount")));
                    paymentList.add(String.valueOf(result.getString("paid_date")));
                    paymentList.add(String.valueOf(result.getString("student.email")));
                    paymentList.add(String.valueOf(result.getString("student.first_name") + " " + result.getString("student.last_name")));
                    paymentList.add(String.valueOf(result.getString("teacher.email")));
                    paymentList.add(String.valueOf(result.getString("teacher.first_name") + " " + result.getString("teacher.last_name")));
                    paymentList.add(String.valueOf(result.getString("subject.name")));
                    paymentList.add(String.valueOf(result.getString("month")));
                    tableModel.addRow(paymentList);
                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }
        }
    }

    private void loadData1(String searchtxt) {

        if (searchtxt.equals("")) {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `teacher_invoice` INNER JOIN `teacher` ON `teacher`.`id`=`teacher_invoice`.`teacher_id` "
                        + "INNER JOIN `subject` ON `subject`.`id`=`teacher_invoice`.`subject_id` "
                        + "INNER JOIN `month` ON `month`.`month_id`=`teacher_invoice`.`month_month_id`");
                DefaultTableModel tableModel = (DefaultTableModel) jTable2.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> paymentList = new Vector();
                    count++;
                    paymentList.add(String.valueOf(count));
                    paymentList.add(String.valueOf(result.getString("invoice_id")));
                    paymentList.add(String.valueOf(result.getString("paid_amount")));
                    paymentList.add(String.valueOf(result.getString("paid_date")));
                    paymentList.add(String.valueOf(result.getString("teacher.email")));
                    paymentList.add(String.valueOf(result.getString("teacher.first_name") + " " + result.getString("teacher.last_name")));
                    paymentList.add(String.valueOf(result.getString("subject.name")));
                    paymentList.add(String.valueOf(result.getString("month")));
                    tableModel.addRow(paymentList);
                }
            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        } else {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `teacher_invoice` INNER JOIN `teacher` ON `teacher`.`id`=`teacher_invoice`.`teacher_id` "
                        + "INNER JOIN `subject` ON `subject`.`id`=`teacher_invoice`.`subject_id`"
                        + "INNER JOIN `month` ON `month`.`month_id`=`teacher_invoice`.`month_month_id` WHERE `invoice_id`LIKE'%" + searchtxt + "%' OR `teacher`.`email`LIKE'%" + searchtxt + "%'");
                DefaultTableModel tableModel = (DefaultTableModel) jTable2.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> paymentList = new Vector();
                    count++;
                    paymentList.add(String.valueOf(count));
                    paymentList.add(String.valueOf(result.getString("invoice_id")));
                    paymentList.add(String.valueOf(result.getString("paid_amount")));
                    paymentList.add(String.valueOf(result.getString("paid_date")));
                    paymentList.add(String.valueOf(result.getString("teacher.email")));
                    paymentList.add(String.valueOf(result.getString("teacher.first_name") + " " + result.getString("teacher.last_name")));
                    paymentList.add(String.valueOf(result.getString("subject.name")));
                    paymentList.add(String.valueOf(result.getString("month")));
                    tableModel.addRow(paymentList);
                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }
        }
    }

    private void reset() {
        String id = String.valueOf(System.currentTimeMillis());
        invoiceInput.setText(id);
        invoiceInput.setEditable(false);
        studentInput.setText("");
        studentLabel.setText("");
        teacherInput.setText("");
        teacherLabel.setText("");
        subjectCombo.setSelectedIndex(0);
        payInput.setText("00.0");
        monthCombo.setSelectedIndex(0);
        paymentLabel.setText("00,00");
        totalLabel.setText("00,00");
        dueLabel.setText("00,00");
        studentEmail.setText("example@gmail.com");

        invoiceInput1.setText(id);
        invoiceInput1.setEditable(false);
        teacherInput1.setText("");
        teacherLabel1.setText("");
        subjectCombo1.setSelectedIndex(0);
        payInput1.setText("00.0");
        monthCombo1.setSelectedIndex(0);
        paymentLabel1.setText("00,00");
        totalLabel1.setText("00,00");
        dueLabel1.setText("00,00");
        teacherEmail1.setText("example@gmail.com");
    }

    private void loadPrice() {
        if (subjectCombo.getSelectedIndex() == 0) {
            payInput.setText("00.0");
        } else {
            String s = String.valueOf(subjectCombo.getSelectedItem());
            String subject = SubjectMap.get(s);

            try {
                ResultSet result = MySQL.search("SELECT * FROM `subject` WHERE `id`='" + subject + "'");

                if (result.next()) {
                    payInput.setText(result.getString("price"));
                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }
        }
    }

    private void loadPrice1() {
        if (subjectCombo1.getSelectedIndex() == 0) {
            payInput1.setText("00.0");
        } else {
            String s = String.valueOf(subjectCombo1.getSelectedItem());
            String subject = SubjectMap.get(s);

            try {
                ResultSet result = MySQL.search("SELECT * FROM `subject` WHERE `id`='" + subject + "'");

                if (result.next()) {
                    payInput1.setText(result.getString("price"));
                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }
        }
    }

    private void loadMonth() {
        try {

            ResultSet result = MySQL.search("SELECT * FROM `month`");

            Vector<String> v = new Vector<>();
            v.add("Select");
            while (result.next()) {
                v.add(result.getString("month"));
            }
            DefaultComboBoxModel cm = new DefaultComboBoxModel(v);
            this.monthCombo.setModel(cm);
            this.monthCombo1.setModel(cm);

        } catch (SQLException e) {
            AdminDashboard.logger.warning(e.getMessage());
        }

    }

    private void loadSubejct() {
        try {
            ResultSet result = MySQL.search("SELECT * FROM `subject`");
            Vector<String> subject = new Vector<>();
            subject.add("Select");
            while (result.next()) {
                subject.add(result.getString("name"));
                SubjectMap.put(result.getString("name"), result.getString("id"));
            }
            DefaultComboBoxModel comboBoxModel = new DefaultComboBoxModel(subject);
            this.subjectCombo.setModel(comboBoxModel);
            this.subjectCombo1.setModel(comboBoxModel);

        } catch (SQLException e) {
            AdminDashboard.logger.warning(e.getMessage());
        }
    }

    private void rest() {
        String id = String.valueOf(System.currentTimeMillis());
        invoiceInput.setText(id);
        invoiceInput.setEditable(false);

    }

    public JTextField getstudentInput() {
        return studentInput;
    }

    public JTextField getstudentLabel() {
        return studentLabel;
    }

    public JTextField getteacherInput() {
        return teacherInput;
    }

    public JTextField getteacherLabel() {
        return teacherLabel;
    }

    public JTextField getteacherInput1() {
        return teacherInput1;
    }

    public JTextField getteacherLabel1() {
        return teacherLabel1;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        navbarPanel = new javax.swing.JPanel();
        search = new lk.hililk.adyapana.component.HRoundTextField();
        name = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator1 = new javax.swing.JSeparator();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        student = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel17 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        invoiceInput = new lk.hililk.adyapana.component.HRoundTextField();
        jLabel18 = new javax.swing.JLabel();
        monthCombo = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        payInput = new lk.hililk.adyapana.component.HRoundTextField();
        studentInput = new lk.hililk.adyapana.component.HRoundTextField();
        jButton4 = new javax.swing.JButton();
        subjectCombo = new javax.swing.JComboBox<>();
        studentLabel = new lk.hililk.adyapana.component.HRoundTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        totalLabel = new javax.swing.JLabel();
        paymentLabel = new javax.swing.JLabel();
        dueLabel = new javax.swing.JLabel();
        roundButton1 = new lk.hililk.adyapana.component.RoundButton();
        jLabel21 = new javax.swing.JLabel();
        teacherInput = new lk.hililk.adyapana.component.HRoundTextField();
        jButton5 = new javax.swing.JButton();
        teacherLabel = new lk.hililk.adyapana.component.HRoundTextField();
        jLabel15 = new javax.swing.JLabel();
        studentEmail = new javax.swing.JLabel();
        teacher = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        invoiceInput1 = new lk.hililk.adyapana.component.HRoundTextField();
        jLabel33 = new javax.swing.JLabel();
        teacherInput1 = new lk.hililk.adyapana.component.HRoundTextField();
        teacherLabel1 = new lk.hililk.adyapana.component.HRoundTextField();
        jButton7 = new javax.swing.JButton();
        jLabel34 = new javax.swing.JLabel();
        subjectCombo1 = new javax.swing.JComboBox<>();
        jLabel35 = new javax.swing.JLabel();
        payInput1 = new lk.hililk.adyapana.component.HRoundTextField();
        jLabel36 = new javax.swing.JLabel();
        monthCombo1 = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        teacherEmail1 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        totalLabel1 = new javax.swing.JLabel();
        paymentLabel1 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        dueLabel1 = new javax.swing.JLabel();
        roundButton2 = new lk.hililk.adyapana.component.RoundButton();

        navbarPanel.setPreferredSize(new java.awt.Dimension(0, 60));

        search.setToolTipText("");
        search.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
        });

        name.setFont(new java.awt.Font("Signika Light", 0, 18)); // NOI18N
        name.setForeground(new java.awt.Color(102, 102, 102));
        name.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        name.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/user.png"))); // NOI18N
        name.setText("  Hirusha Liyanage");

        javax.swing.GroupLayout navbarPanelLayout = new javax.swing.GroupLayout(navbarPanel);
        navbarPanel.setLayout(navbarPanelLayout);
        navbarPanelLayout.setHorizontalGroup(
            navbarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addGroup(navbarPanelLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(search, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
            .addComponent(jSeparator1)
        );
        navbarPanelLayout.setVerticalGroup(
            navbarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(navbarPanelLayout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addGroup(navbarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel8.setFont(new java.awt.Font("Signika", 0, 18)); // NOI18N
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/payments.png"))); // NOI18N
        jLabel8.setText("Student's Payments");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jButton1.setBackground(new java.awt.Color(0, 0, 153));
        jButton1.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/tick.png"))); // NOI18N
        jButton1.setText("Add Payment");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Signika Light", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "Invoice No", "Paid Amount", "Paid Date", "Student Email", "Student", "Teacher Email", "Teacher", "Subject", "Month"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel17.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel17.setText("Subject Name");
        jLabel17.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel17MouseClicked(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel20.setText("Student");
        jLabel20.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel20MouseClicked(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel7.setText("Payment Amount");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        invoiceInput.setToolTipText("");
        invoiceInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        invoiceInput.setMargin(new java.awt.Insets(0, 50, 0, 10));
        invoiceInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invoiceInputActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel18.setText("Month");
        jLabel18.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel18MouseClicked(evt);
            }
        });

        monthCombo.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        monthCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "January", "Februrary", "March", "April", "May", "June", "July", "August", "September", "October", "Novemeber", "December" }));

        jLabel9.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel9.setText("Invoice Number");
        jLabel9.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        payInput.setToolTipText("");
        payInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        payInput.setMargin(new java.awt.Insets(0, 50, 0, 10));
        payInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payInputActionPerformed(evt);
            }
        });

        studentInput.setToolTipText("");
        studentInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        studentInput.setMargin(new java.awt.Insets(0, 50, 0, 10));
        studentInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentInputActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(0, 102, 204));
        jButton4.setFont(new java.awt.Font("Signika Light", 0, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("+");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        subjectCombo.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        subjectCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mathematics", "Science", "Sinhala", "English" }));
        subjectCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectComboActionPerformed(evt);
            }
        });

        studentLabel.setToolTipText("");
        studentLabel.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        studentLabel.setMargin(new java.awt.Insets(0, 50, 0, 10));
        studentLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentLabelActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel12.setText("Total :");
        jLabel12.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel13.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel13.setText("Paid Amount :");
        jLabel13.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel14.setText("Due Payment :");
        jLabel14.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });

        totalLabel.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        totalLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        totalLabel.setText("00.00");
        totalLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        totalLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                totalLabelMouseClicked(evt);
            }
        });

        paymentLabel.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        paymentLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        paymentLabel.setText("00.00");
        paymentLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        paymentLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                paymentLabelMouseClicked(evt);
            }
        });

        dueLabel.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        dueLabel.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        dueLabel.setText("00.00");
        dueLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        dueLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dueLabelMouseClicked(evt);
            }
        });

        roundButton1.setBackground(new java.awt.Color(0, 0, 0));
        roundButton1.setForeground(new java.awt.Color(255, 255, 255));
        roundButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/print.png"))); // NOI18N
        roundButton1.setText(" Print Invoice");
        roundButton1.setFont(new java.awt.Font("Signika", 0, 16)); // NOI18N
        roundButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roundButton1ActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel21.setText("Teacher");
        jLabel21.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });

        teacherInput.setToolTipText("");
        teacherInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        teacherInput.setMargin(new java.awt.Insets(0, 50, 0, 10));
        teacherInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherInputActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(0, 102, 204));
        jButton5.setFont(new java.awt.Font("Signika Light", 0, 18)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("+");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        teacherLabel.setToolTipText("");
        teacherLabel.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        teacherLabel.setMargin(new java.awt.Insets(0, 50, 0, 10));
        teacherLabel.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                teacherLabelInputMethodTextChanged(evt);
            }
        });
        teacherLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherLabelActionPerformed(evt);
            }
        });
        teacherLabel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                teacherLabelKeyReleased(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel15.setText("Student's Email");
        jLabel15.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        studentEmail.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        studentEmail.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        studentEmail.setText("example@gmail.com");
        studentEmail.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        studentEmail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                studentEmailMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout studentLayout = new javax.swing.GroupLayout(student);
        student.setLayout(studentLayout);
        studentLayout.setHorizontalGroup(
            studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(studentLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(studentLayout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, studentLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(studentLayout.createSequentialGroup()
                                .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(studentLayout.createSequentialGroup()
                                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(teacherLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, studentLayout.createSequentialGroup()
                                                .addComponent(teacherInput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jButton5))
                                            .addComponent(studentLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, studentLayout.createSequentialGroup()
                                                .addComponent(studentInput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jButton4))
                                            .addComponent(invoiceInput, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(studentLayout.createSequentialGroup()
                                                .addComponent(payInput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(4, 4, 4))
                                            .addGroup(studentLayout.createSequentialGroup()
                                                .addComponent(monthCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(3, 3, 3)))
                                        .addGap(4, 4, 4)))
                                .addGap(49, 49, 49))
                            .addGroup(studentLayout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(studentLayout.createSequentialGroup()
                                .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)
                                        .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)
                                        .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE))
                                    .addComponent(subjectCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(studentLayout.createSequentialGroup()
                                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE)
                                        .addGap(3, 3, 3)))
                                .addGap(53, 53, 53)))
                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, studentLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(roundButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, studentLayout.createSequentialGroup()
                                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(paymentLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(totalLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(dueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, studentLayout.createSequentialGroup()
                                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(studentEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(51, 51, 51))))
        );
        studentLayout.setVerticalGroup(
            studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(studentLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(studentLayout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(invoiceInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(studentInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(studentLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                            .addComponent(teacherInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(teacherLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(subjectCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7))
                    .addGroup(studentLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 402, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(studentLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(payInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(monthCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(studentLayout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(studentEmail))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(totalLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(paymentLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(studentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(dueLabel))
                        .addGap(7, 7, 7)
                        .addComponent(roundButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(113, 113, 113))
        );

        jTabbedPane1.addTab("Student's Payment", student);

        jLabel11.setFont(new java.awt.Font("Signika", 0, 18)); // NOI18N
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/payments.png"))); // NOI18N
        jLabel11.setText("Teacher's Payments");
        jLabel11.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel32.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel32.setText("Invoice Number");
        jLabel32.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        invoiceInput1.setToolTipText("");
        invoiceInput1.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        invoiceInput1.setMargin(new java.awt.Insets(0, 50, 0, 10));
        invoiceInput1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invoiceInput1ActionPerformed(evt);
            }
        });

        jLabel33.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel33.setText("Teacher's Email");
        jLabel33.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        teacherInput1.setToolTipText("");
        teacherInput1.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        teacherInput1.setMargin(new java.awt.Insets(0, 50, 0, 10));
        teacherInput1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherInput1ActionPerformed(evt);
            }
        });

        teacherLabel1.setToolTipText("");
        teacherLabel1.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        teacherLabel1.setMargin(new java.awt.Insets(0, 50, 0, 10));
        teacherLabel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherLabel1ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(0, 102, 204));
        jButton7.setFont(new java.awt.Font("Signika Light", 0, 18)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("+");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel34.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel34.setText("Subject Name");
        jLabel34.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        subjectCombo1.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        subjectCombo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mathematics", "Science", "Sinhala", "English" }));
        subjectCombo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectCombo1ActionPerformed(evt);
            }
        });

        jLabel35.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel35.setText("Payment Amount");
        jLabel35.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        payInput1.setToolTipText("");
        payInput1.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        payInput1.setMargin(new java.awt.Insets(0, 50, 0, 10));
        payInput1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payInput1ActionPerformed(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel36.setText("Month");
        jLabel36.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        monthCombo1.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        monthCombo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "January", "Februrary", "March", "April", "May", "June", "July", "August", "September", "October", "Novemeber", "December" }));

        jButton2.setBackground(new java.awt.Color(0, 0, 153));
        jButton2.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/tick.png"))); // NOI18N
        jButton2.setText("Add Payment");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTable2.setFont(new java.awt.Font("Signika Light", 0, 12)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "Invoice No", "Paid Amount", "Paid Date", "Teacher", "Teacher Email", "Subject", "Month"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTable2KeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jLabel16.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel16.setText("Teacher's Email");
        jLabel16.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        teacherEmail1.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        teacherEmail1.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        teacherEmail1.setText("example@gmail.com");
        teacherEmail1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        teacherEmail1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                teacherEmail1MouseClicked(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel19.setText("Total :");
        jLabel19.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        totalLabel1.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        totalLabel1.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        totalLabel1.setText("00.00");
        totalLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        totalLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                totalLabel1MouseClicked(evt);
            }
        });

        paymentLabel1.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        paymentLabel1.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        paymentLabel1.setText("00.00");
        paymentLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        paymentLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                paymentLabel1MouseClicked(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel22.setText("Paid Amount :");
        jLabel22.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel22MouseClicked(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jLabel23.setText("Due Payment :");
        jLabel23.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel23MouseClicked(evt);
            }
        });

        dueLabel1.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        dueLabel1.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        dueLabel1.setText("00.00");
        dueLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        dueLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dueLabel1MouseClicked(evt);
            }
        });

        roundButton2.setBackground(new java.awt.Color(0, 0, 0));
        roundButton2.setForeground(new java.awt.Color(255, 255, 255));
        roundButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/print.png"))); // NOI18N
        roundButton2.setText(" Print Invoice");
        roundButton2.setFont(new java.awt.Font("Signika", 0, 16)); // NOI18N
        roundButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roundButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout teacherLayout = new javax.swing.GroupLayout(teacher);
        teacher.setLayout(teacherLayout);
        teacherLayout.setHorizontalGroup(
            teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(teacherLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(teacherLayout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, teacherLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(teacherLayout.createSequentialGroup()
                                .addComponent(teacherInput1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton7)
                                .addGap(53, 53, 53))
                            .addGroup(teacherLayout.createSequentialGroup()
                                .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel36, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(monthCombo1, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(teacherLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(invoiceInput1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(49, 49, 49))
                            .addGroup(teacherLayout.createSequentialGroup()
                                .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(payInput1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel35, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, teacherLayout.createSequentialGroup()
                                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel32, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(jLabel34, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)
                                                .addComponent(jLabel33, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)))
                                        .addGap(0, 97, Short.MAX_VALUE))
                                    .addComponent(subjectCombo1, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(57, 57, 57)))
                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 801, Short.MAX_VALUE)
                            .addGroup(teacherLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(roundButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, teacherLayout.createSequentialGroup()
                                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(paymentLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(totalLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(dueLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, teacherLayout.createSequentialGroup()
                                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(teacherEmail1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(51, 51, 51))))
        );
        teacherLayout.setVerticalGroup(
            teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(teacherLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(teacherLayout.createSequentialGroup()
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(invoiceInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel33)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                            .addComponent(teacherInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(teacherLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(subjectCombo1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel35)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(payInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel36)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(monthCombo1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(teacherLayout.createSequentialGroup()
                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(teacherEmail1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(totalLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(paymentLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(teacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23)
                            .addComponent(dueLabel1))
                        .addGap(7, 7, 7)
                        .addComponent(roundButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Teacher's Payment", teacher);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
            .addComponent(navbarPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1257, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(navbarPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 731, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    private void studentInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentInputActionPerformed

    private void payInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_payInputActionPerformed

    private void jLabel18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel18MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel18MouseClicked

    private void invoiceInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invoiceInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_invoiceInputActionPerformed

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked

    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel20MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel20MouseClicked

    private void jLabel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel17MouseClicked

    }//GEN-LAST:event_jLabel17MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String invoice_no = invoiceInput.getText();
        String st = studentLabel.getText();
        String t = teacherLabel.getText();
        String s = String.valueOf(subjectCombo.getSelectedItem());
        String subject = SubjectMap.get(s);
        String payment = payInput.getText();
        String month = String.valueOf(monthCombo.getSelectedIndex());
        java.util.Date date = new java.util.Date();
        java.text.SimpleDateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd  hh:mm:ss");
        String nowDate = format1.format(date);

        if (st.isEmpty()) {
            JOptionPane.showMessageDialog(this, "A Student is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (t.isEmpty()) {
            JOptionPane.showMessageDialog(this, "A Teacher is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (s.equals("Select")) {
            JOptionPane.showMessageDialog(this, "A Subject is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (payment.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Payment Amount is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (payment.equals("00.00")) {
            JOptionPane.showMessageDialog(this, "Invalid Payment Amount", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (Double.parseDouble(payment) < 0) {
            JOptionPane.showMessageDialog(this, "Invalid Payment Amount", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (month.equals("0")) {
            JOptionPane.showMessageDialog(this, "Month is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `teacher` WHERE `email`='" + t + "'");

                if (result.next()) {
                    String teacher = result.getString("id");

                    ResultSet result1 = MySQL.search("SELECT * FROM `student` WHERE `email`='" + st + "'");

                    if (result1.next()) {
                        String student = result.getString("id");

                        ResultSet cresult = MySQL.search("SELECT * FROM `teacher_has_subject` WHERE `teacher_id`='" + teacher + "' AND `subject_id`='" + subject + "' ");

                        if (cresult.next()) {
                            MySQL.iud("INSERT INTO `student_invoice` (`invoice_id`,`paid_amount`,`paid_date`,`student_id`,`teacher_id`,`subject_id`,`month_month_id`) VALUES ('" + invoice_no + "','" + payment + "','" + nowDate + "','" + student + "',"
                                    + "'" + teacher + "','" + subject + "','" + month + "') ");
                            Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully added Payment.");
                            loadData("");
                            reset();
                        } else {
                            Notifications.getInstance().show(Notifications.Type.ERROR, Notifications.Location.TOP_CENTER, "This subject is not a subject of this teacher.");
                        }

                    }

                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void studentLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentLabelActionPerformed


    }//GEN-LAST:event_studentLabelActionPerformed

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel13MouseClicked

    private void totalLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_totalLabelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_totalLabelMouseClicked

    private void paymentLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paymentLabelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_paymentLabelMouseClicked

    private void roundButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roundButton1ActionPerformed
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            Notifications.getInstance().show(Notifications.Type.WARNING, Notifications.Location.TOP_CENTER, "Please Select a Row Before Update!");

        } else {
            HashMap<String, Object> parameters = new HashMap<>();

            String invoiceId = String.valueOf(jTable1.getValueAt(selectedRow, 1));
            String payment = String.valueOf(jTable1.getValueAt(selectedRow, 2));
            String student = String.valueOf(jTable1.getValueAt(selectedRow, 4));
            String studentName = String.valueOf(jTable1.getValueAt(selectedRow, 5));
            String subject = String.valueOf(jTable1.getValueAt(selectedRow, 8));
            loadData(invoiceId);

            try {

                ResultSet result = MySQL.search("SELECT * FROM `subject` WHERE `name`='" + subject + "'");

                if (result.next()) {
                    Double price = Double.parseDouble(result.getString("price"));
                    Double payment1 = Double.parseDouble(payment);
                    String due1 = String.valueOf(price - payment1);
                    totalLabel.setText(result.getString("price"));
                    dueLabel.setText(due1);
                    parameters.put("Parameter1", invoiceId);
                    parameters.put("Parameter2", studentName);
                    parameters.put("Parameter3", String.valueOf(price));
                    parameters.put("Parameter4", payment);
                    parameters.put("Parameter5", due1);
                }

                String filePath = "src//lk//hililk//adyapana//reports//Blank_A4_Landscape.jasper";

                JRTableModelDataSource dataSoruce = new JRTableModelDataSource(jTable1.getModel());
                JasperPrint jasperPrint = JasperFillManager.fillReport(filePath, parameters, dataSoruce);
                JasperViewer.viewReport(jasperPrint, false);
                reset();
                loadData("");
            } catch (SQLException | JRException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }


    }//GEN-LAST:event_roundButton1ActionPerformed

    private void invoiceInput1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invoiceInput1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_invoiceInput1ActionPerformed

    private void teacherInput1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherInput1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherInput1ActionPerformed

    private void teacherLabel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherLabel1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherLabel1ActionPerformed

    private void payInput1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payInput1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_payInput1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String invoice_no = invoiceInput1.getText();
        String t = teacherLabel1.getText();
        String s = String.valueOf(subjectCombo1.getSelectedItem());
        String subject = SubjectMap.get(s);
        String payment = payInput1.getText();
        String month = String.valueOf(monthCombo1.getSelectedIndex());
        java.util.Date date = new java.util.Date();
        java.text.SimpleDateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd  hh:mm:ss");
        String nowDate = format1.format(date);

        if (t.isEmpty()) {
            JOptionPane.showMessageDialog(this, "A Teacher is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (s.equals("Select")) {
            JOptionPane.showMessageDialog(this, "A Subject is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (payment.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Payment Amount is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (payment.equals("00.00")) {
            JOptionPane.showMessageDialog(this, "Invalid Payment Amount", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (Double.parseDouble(payment) < 0) {
            JOptionPane.showMessageDialog(this, "Invalid Payment Amount", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (month.equals("0")) {
            JOptionPane.showMessageDialog(this, "Month is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `teacher` WHERE `email`='" + t + "'");

                if (result.next()) {
                    String teacher = result.getString("id");

                    String student = result.getString("id");

                    ResultSet cresult = MySQL.search("SELECT * FROM `teacher_has_subject` WHERE `teacher_id`='" + teacher + "' AND `subject_id`='" + subject + "' ");

                    if (cresult.next()) {
                        MySQL.iud("INSERT INTO `teacher_invoice` (`invoice_id`,`paid_amount`,`paid_date`,`teacher_id`,`subject_id`,`month_month_id`) VALUES ('" + invoice_no + "','" + payment + "','" + nowDate + "',"
                                + "'" + teacher + "','" + subject + "','" + month + "') ");
                        Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully added Payment.");
                        loadData1("");
                        reset();
                    } else {
                        Notifications.getInstance().show(Notifications.Type.ERROR, Notifications.Location.TOP_CENTER, "This subject is not a subject of this teacher.");
                    }

                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel21MouseClicked

    private void teacherInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherInputActionPerformed

    private void teacherLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherLabelActionPerformed

    }//GEN-LAST:event_teacherLabelActionPerformed

    private void loadTSubjects() {

        String teacher = teacherLabel.getText();

        try {
            ResultSet result = MySQL.search("SELECT * FROM `teacher` WHERE `email`='" + teacher + "'");
            if (result.next()) {
                String id = result.getString("id");

                ResultSet result1 = MySQL.search("SELECT * FROM `teacher_has_subject` INNER JOIN `subject` ON `subject`.`id`=`teacher_has_subject`.`subject_id` WHERE `teacher_id`='" + id + "' ");

                Vector<String> v = new Vector<>();
                v.add("Select");
                while (result1.next()) {
                    v.add(result1.getString("subject.name"));
                    System.out.println(result1.getString("subject.name"));
                }
                DefaultComboBoxModel comboBoxModel = new DefaultComboBoxModel(v);
                this.subjectCombo.setModel(comboBoxModel);

            }
        } catch (SQLException e) {
            AdminDashboard.logger.warning(e.getMessage());
        }
    }


    private void dueLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dueLabelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dueLabelMouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel14MouseClicked

    private void subjectComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectComboActionPerformed
        loadPrice();
    }//GEN-LAST:event_subjectComboActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        student s = new student();
        s.setVisible(true);
        s.setStudent(this);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        teacher2 t = new teacher2();
        t.setVisible(true);
        t.setTeacher(this);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void teacherLabelKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_teacherLabelKeyReleased

    }//GEN-LAST:event_teacherLabelKeyReleased

    private void teacherLabelInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_teacherLabelInputMethodTextChanged

    }//GEN-LAST:event_teacherLabelInputMethodTextChanged

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if (evt.getClickCount() == 2) {
            int selectedRow = jTable1.getSelectedRow();

            String invoiceId = String.valueOf(jTable1.getValueAt(selectedRow, 1));
            String payment = String.valueOf(jTable1.getValueAt(selectedRow, 2));
            String student = String.valueOf(jTable1.getValueAt(selectedRow, 4));
            String studentName = String.valueOf(jTable1.getValueAt(selectedRow, 5));
            String subject = String.valueOf(jTable1.getValueAt(selectedRow, 8));

            studentEmail.setText(student);
            paymentLabel.setText(payment);

            try {

                ResultSet result = MySQL.search("SELECT * FROM `subject` WHERE `name`='" + subject + "'");

                if (result.next()) {
                    Double price = Double.parseDouble(result.getString("price"));
                    Double payment1 = Double.parseDouble(payment);
                    String due1 = String.valueOf(price - payment1);
                    totalLabel.setText(result.getString("price"));
                    dueLabel.setText(due1);
                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void studentEmailMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_studentEmailMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_studentEmailMouseClicked

    private void teacherEmail1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_teacherEmail1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherEmail1MouseClicked

    private void totalLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_totalLabel1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_totalLabel1MouseClicked

    private void paymentLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paymentLabel1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_paymentLabel1MouseClicked

    private void jLabel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel22MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel22MouseClicked

    private void jLabel23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel23MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel23MouseClicked

    private void dueLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dueLabel1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_dueLabel1MouseClicked

    private void roundButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roundButton2ActionPerformed
          int selectedRow = jTable2.getSelectedRow();
        if (selectedRow == -1) {
            Notifications.getInstance().show(Notifications.Type.WARNING, Notifications.Location.TOP_CENTER, "Please Select a Row Before Update!");

        } else {
            HashMap<String, Object> parameters = new HashMap<>();

            String invoiceId = String.valueOf(jTable2.getValueAt(selectedRow, 1));
            String payment = String.valueOf(jTable2.getValueAt(selectedRow, 2));
            String teacher = String.valueOf(jTable2.getValueAt(selectedRow, 4));
            String teacherName = String.valueOf(jTable2.getValueAt(selectedRow, 5));
            String subject = String.valueOf(jTable2.getValueAt(selectedRow, 6));

            teacherEmail1.setText(teacher);
            paymentLabel1.setText(payment);
            loadData1(invoiceId);

            try {

                ResultSet result = MySQL.search("SELECT * FROM `subject` WHERE `name`='" + subject + "'");

                if (result.next()) {
                      Double price = Double.parseDouble(result.getString("price"));
                    Double payment1 = Double.parseDouble(payment);
                    String due1 = String.valueOf(price - payment1);
                    totalLabel1.setText(result.getString("price"));
                    dueLabel1.setText(due1);
                    parameters.put("Parameter1", invoiceId);
                    parameters.put("Parameter2", teacherName);
                    parameters.put("Parameter3", String.valueOf(price));
                    parameters.put("Parameter4", payment);
                    parameters.put("Parameter5", due1);
                }

                String filePath = "src//lk//hililk//adyapana//reports//Blank_A4_Landscape1.jasper";

                JRTableModelDataSource dataSoruce = new JRTableModelDataSource(jTable2.getModel());
                JasperPrint jasperPrint = JasperFillManager.fillReport(filePath, parameters, dataSoruce);
                JasperViewer.viewReport(jasperPrint, false);
                reset();
                loadData("");
            } catch (SQLException | JRException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }
        }
    }//GEN-LAST:event_roundButton2ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        teacher4 t = new teacher4();
        t.setVisible(true);
        t.setTeacher(this);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jTable2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable2KeyReleased

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        if (evt.getClickCount() == 2) {
            int selectedRow = jTable2.getSelectedRow();

            String invoiceId = String.valueOf(jTable2.getValueAt(selectedRow, 1));
            String payment = String.valueOf(jTable2.getValueAt(selectedRow, 2));
            String teacher = String.valueOf(jTable2.getValueAt(selectedRow, 4));
            String teacherName = String.valueOf(jTable2.getValueAt(selectedRow, 5));
            String subject = String.valueOf(jTable2.getValueAt(selectedRow, 6));

            teacherEmail1.setText(teacher);
            paymentLabel1.setText(payment);

            try {

                ResultSet result = MySQL.search("SELECT * FROM `subject` WHERE `name`='" + subject + "'");

                if (result.next()) {
                    Double price = Double.parseDouble(result.getString("price"));
                    Double payment1 = Double.parseDouble(payment);
                    String due1 = String.valueOf(price - payment1);
                    totalLabel1.setText(result.getString("price"));
                    dueLabel1.setText(due1);
                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }
    }//GEN-LAST:event_jTable2MouseClicked

    private void subjectCombo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectCombo1ActionPerformed
        loadPrice1();
    }//GEN-LAST:event_subjectCombo1ActionPerformed

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
        String searchtxt = search.getText();
        loadData(searchtxt);
        loadData1(searchtxt);
    }//GEN-LAST:event_searchKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel dueLabel;
    private javax.swing.JLabel dueLabel1;
    private lk.hililk.adyapana.component.HRoundTextField invoiceInput;
    private lk.hililk.adyapana.component.HRoundTextField invoiceInput1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JComboBox<String> monthCombo;
    private javax.swing.JComboBox<String> monthCombo1;
    private javax.swing.JLabel name;
    private javax.swing.JPanel navbarPanel;
    private lk.hililk.adyapana.component.HRoundTextField payInput;
    private lk.hililk.adyapana.component.HRoundTextField payInput1;
    private javax.swing.JLabel paymentLabel;
    private javax.swing.JLabel paymentLabel1;
    private lk.hililk.adyapana.component.RoundButton roundButton1;
    private lk.hililk.adyapana.component.RoundButton roundButton2;
    private lk.hililk.adyapana.component.HRoundTextField search;
    private javax.swing.JPanel student;
    private javax.swing.JLabel studentEmail;
    private lk.hililk.adyapana.component.HRoundTextField studentInput;
    private lk.hililk.adyapana.component.HRoundTextField studentLabel;
    private javax.swing.JComboBox<String> subjectCombo;
    private javax.swing.JComboBox<String> subjectCombo1;
    private javax.swing.JPanel teacher;
    private javax.swing.JLabel teacherEmail1;
    private lk.hililk.adyapana.component.HRoundTextField teacherInput;
    private lk.hililk.adyapana.component.HRoundTextField teacherInput1;
    private lk.hililk.adyapana.component.HRoundTextField teacherLabel;
    private lk.hililk.adyapana.component.HRoundTextField teacherLabel1;
    private javax.swing.JLabel totalLabel;
    private javax.swing.JLabel totalLabel1;
    // End of variables declaration//GEN-END:variables
}
