/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package lk.hililk.adyapana.panel;

import com.formdev.flatlaf.FlatClientProperties;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import lk.hililk.adyapana.connection.MySQL;
import lk.hililk.adyapana.gui.AdminDashboard;
import lk.hililk.adyapana.gui.student1;
import lk.hililk.adyapana.gui.teacher;
import raven.toast.Notifications;

/**
 *
 * @author Hirusha
 */
public class studentSubjectRegistration extends javax.swing.JPanel {

    HashMap<String, String> SubjectMap = new HashMap<>();

    /**
     * Creates new form teacherSubjectRegistration
     */
    public studentSubjectRegistration() {
        initComponents();
        init();
        loadSubejct();
        loadData("");
        loadName();
    }

    private void loadName() {
        String email = AdminDashboard.aEmail;
        try {
            ResultSet result = MySQL.search("SELECT * FROM `admin` WHERE `email`='" + email + "'");
            if (result.next()) {
                name.setText(result.getString("first_name") + " " + result.getString("last_name"));
                System.out.println(result.getString("first_name") + " " + result.getString("last_name"));
            }
        } catch (SQLException e) {
            AdminDashboard.logger.warning(e.getMessage());
        }
    }

    private AdminDashboard adminDashboard;

    public studentSubjectRegistration(AdminDashboard adminDashboard) {
        this();
        this.adminDashboard = adminDashboard;
        Notifications.getInstance().setJFrame(adminDashboard);
    }

    private void init() {
        search.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Search By Student's Name, Email Or Subject Name");
        search.putClientProperty(FlatClientProperties.TEXT_FIELD_LEADING_ICON, new ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/search (2).png")));
        search.putClientProperty(FlatClientProperties.STYLE, "arc:15;" + "margin:5,20,5,20");
        teacherInput.setEditable(false);
        teacherLabel.setEditable(false);
        teacherInput.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Student Name");
        teacherLabel.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Student Email");
    }

    private void loadData(String searchtxt) {

        if (searchtxt.equals("")) {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `subject_has_student` INNER JOIN `student` ON `student`.`id`=`subject_has_student`.`student_id` "
                        + "INNER JOIN `subject` ON `subject`.`id`=`subject_has_student`.`subject_id`");
                DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> subjectList = new Vector();
                    count++;
                    subjectList.add(String.valueOf(count));
                    subjectList.add(String.valueOf(result.getString("id")));
                    subjectList.add(String.valueOf(result.getString("student.first_name") + " " + result.getString("student.last_name")));
                    subjectList.add(String.valueOf(result.getString("student.email")));
                    subjectList.add(String.valueOf(result.getString("subject.name")));
                    tableModel.addRow(subjectList);
                }
            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        } else {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `subject_has_student` INNER JOIN `student` ON `student`.`id`=`subject_has_student`.`student_id` "
                        + "INNER JOIN `subject` ON `subject`.`id`=`subject_has_student`.`subject_id` WHERE"
                        + "`student`.`first_name`LIKE'%" + searchtxt + "%' OR `student`.`last_name`LIKE'%" + searchtxt + "%' OR `student`.`email`LIKE'%" + searchtxt + "%' OR `subject`.`name`LIKE'%" + searchtxt + "%'  ");
                DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> subjectList = new Vector();
                    count++;
                    subjectList.add(String.valueOf(count));
                    subjectList.add(String.valueOf(result.getString("id")));
                    subjectList.add(String.valueOf(result.getString("student.first_name") + " " + result.getString("student.last_name")));
                    subjectList.add(String.valueOf(result.getString("student.email")));
                    subjectList.add(String.valueOf(result.getString("subject.name")));
                    tableModel.addRow(subjectList);
                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }
        }
    }

    public JTextField getstudentInput() {
        return teacherInput;
    }

    public JTextField getstudentLabel() {
        return teacherLabel;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        navbarPanel = new javax.swing.JPanel();
        search = new lk.hililk.adyapana.component.HRoundTextField();
        name = new javax.swing.JLabel();
        contentPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        registerBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        subjectCombo = new javax.swing.JComboBox<>();
        teacherInput = new lk.hililk.adyapana.component.HRoundTextField();
        jButton4 = new javax.swing.JButton();
        teacherLabel = new lk.hililk.adyapana.component.HRoundTextField();

        navbarPanel.setPreferredSize(new java.awt.Dimension(0, 60));

        search.setToolTipText("");
        search.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
        });

        name.setFont(new java.awt.Font("Signika Light", 0, 18)); // NOI18N
        name.setForeground(new java.awt.Color(102, 102, 102));
        name.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        name.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/user.png"))); // NOI18N
        name.setText("  Hirusha Liyanage");

        javax.swing.GroupLayout navbarPanelLayout = new javax.swing.GroupLayout(navbarPanel);
        navbarPanel.setLayout(navbarPanelLayout);
        navbarPanelLayout.setHorizontalGroup(
            navbarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(navbarPanelLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(search, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(23, 23, 23)
                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5))
        );
        navbarPanelLayout.setVerticalGroup(
            navbarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(navbarPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        contentPanel.setPreferredSize(new java.awt.Dimension(0, 100));
        contentPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contentPanelMouseClicked(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Signika Light", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "ID", "Student Name", "Student Email", "Subject"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel7.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel7.setText("Subject Name");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Signika", 0, 18)); // NOI18N
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/st.png"))); // NOI18N
        jLabel8.setText("Student As Subject Registration");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel9.setText("Student Name");
        jLabel9.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        registerBtn.setBackground(new java.awt.Color(0, 0, 153));
        registerBtn.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        registerBtn.setForeground(new java.awt.Color(255, 255, 255));
        registerBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/tick.png"))); // NOI18N
        registerBtn.setText("Register Student As Subject");
        registerBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerBtnActionPerformed(evt);
            }
        });

        updateBtn.setBackground(new java.awt.Color(102, 204, 0));
        updateBtn.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        updateBtn.setForeground(new java.awt.Color(255, 255, 255));
        updateBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/update.png"))); // NOI18N
        updateBtn.setText("Update Student As Subject");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        deleteBtn.setBackground(new java.awt.Color(204, 0, 0));
        deleteBtn.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        deleteBtn.setForeground(new java.awt.Color(255, 255, 255));
        deleteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/bin.png"))); // NOI18N
        deleteBtn.setText("Delete Student As Subject");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        jSeparator1.setBackground(new java.awt.Color(153, 153, 153));

        subjectCombo.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        subjectCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mathematics", "Science", "Sinhala", "English" }));

        teacherInput.setToolTipText("");
        teacherInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        teacherInput.setMargin(new java.awt.Insets(0, 50, 0, 10));
        teacherInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherInputActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(0, 102, 204));
        jButton4.setFont(new java.awt.Font("Signika Light", 0, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("+");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        teacherLabel.setToolTipText("");
        teacherLabel.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        teacherLabel.setMargin(new java.awt.Insets(0, 50, 0, 10));
        teacherLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherLabelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout contentPanelLayout = new javax.swing.GroupLayout(contentPanel);
        contentPanel.setLayout(contentPanelLayout);
        contentPanelLayout.setHorizontalGroup(
            contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentPanelLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(contentPanelLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(contentPanelLayout.createSequentialGroup()
                        .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(contentPanelLayout.createSequentialGroup()
                                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 167, Short.MAX_VALUE))
                            .addComponent(registerBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(updateBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(deleteBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(subjectCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(contentPanelLayout.createSequentialGroup()
                                .addComponent(teacherInput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton4))
                            .addComponent(teacherLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(26, 26, 26)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 821, Short.MAX_VALUE)
                        .addGap(26, 26, 26))))
            .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 1166, Short.MAX_VALUE))
        );
        contentPanelLayout.setVerticalGroup(
            contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(contentPanelLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(subjectCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(teacherInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(teacherLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(registerBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 471, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(42, Short.MAX_VALUE))
            .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(contentPanelLayout.createSequentialGroup()
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 573, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(navbarPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1292, Short.MAX_VALUE)
            .addComponent(contentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1292, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(navbarPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contentPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 576, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    private void loadSubejct() {
        try {
            ResultSet result = MySQL.search("SELECT * FROM `subject`");
            Vector<String> subject = new Vector<>();
            subject.add("Select");
            while (result.next()) {
                subject.add(result.getString("name"));
                SubjectMap.put(result.getString("name"), result.getString("id"));
            }
            DefaultComboBoxModel comboBoxModel = new DefaultComboBoxModel(subject);
            this.subjectCombo.setModel(comboBoxModel);

        } catch (SQLException e) {
            AdminDashboard.logger.warning(e.getMessage());
        }
    }

    private void reset() {
        subjectCombo.setSelectedItem("Select");
        teacherInput.setText("");
        teacherLabel.setText("");
        subjectCombo.grabFocus();
    }

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
        String searchtxt = search.getText();
        loadData(searchtxt);
    }//GEN-LAST:event_searchKeyReleased

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if (evt.getClickCount() == 2) {
            int selectedRow = jTable1.getSelectedRow();

            String student = String.valueOf(jTable1.getValueAt(selectedRow, 3));
            String subject = String.valueOf(jTable1.getValueAt(selectedRow, 4));
            subjectCombo.setSelectedItem(subject);
            registerBtn.setEnabled(false);
//            jTable1.setEnabled(false);

            try {

                ResultSet result = MySQL.search("SELECT * FROM `student` WHERE `email`='" + student + "'");

                if (result.next()) {
                    teacherInput.setText(result.getString("first_name") + " " + result.getString("last_name"));
                    teacherLabel.setText(student);

                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked

    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseClicked

    private void registerBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerBtnActionPerformed

        String s = String.valueOf(subjectCombo.getSelectedItem());
        String subject = SubjectMap.get(s);
        String st = teacherLabel.getText();

        if (s.equals("Select")) {
            JOptionPane.showMessageDialog(this, "Subject Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (st.equals("")) {
            JOptionPane.showMessageDialog(this, "Student is Required", "Warning", JOptionPane.WARNING_MESSAGE);
        } else {

            try {
                ResultSet result = MySQL.search("SELECT * FROM `student` WHERE `email`='" + st + "'");

                if (result.next()) {

                    String student = result.getString("id");

                    ResultSet result1 = MySQL.search("SELECT * FROM `subject_has_student` WHERE `student_id`='" + student + "' AND `subject_id`='" + subject + "'");
                    if (result1.next()) {
                        Notifications.getInstance().show(Notifications.Type.ERROR, Notifications.Location.TOP_CENTER, "This Input is already exsists.");
                    } else {

                        MySQL.iud("INSERT INTO `subject_has_student` (`student_id`,`subject_id`) VALUES ('" + student + "','" + subject + "')");
                        Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully added the details.");
                        loadData("");
                        reset();
                    }

                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }


    }//GEN-LAST:event_registerBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed

        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            Notifications.getInstance().show(Notifications.Type.WARNING, Notifications.Location.TOP_CENTER, "Please Select a Row Before Update!");
        } else {

            String s = String.valueOf(subjectCombo.getSelectedItem());
            String subject = SubjectMap.get(s);
            String st = teacherLabel.getText();

            if (s.equals("Select")) {
                JOptionPane.showMessageDialog(this, "Subject Required", "Warning", JOptionPane.WARNING_MESSAGE);
            } else if (st.equals("")) {
                JOptionPane.showMessageDialog(this, "Student is Required", "Warning", JOptionPane.WARNING_MESSAGE);
            } else {
                String id = String.valueOf(jTable1.getValueAt(selectedRow, 1));

                try {
                    ResultSet result = MySQL.search("SELECT * FROM `student` WHERE `email`='" + st + "'");

                    if (result.next()) {

                        String student = result.getString("id");

                        MySQL.iud("UPDATE `subject_has_student` SET `student_id`='" + student + "', `subject_id`='" + subject + "'  WHERE `id`='" + id + "'");
                        Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully updated the row.");
                        loadData("");
                        reset();

                    }

                } catch (SQLException e) {
                    AdminDashboard.logger.warning(e.getMessage());
                }

            }

        }

    }//GEN-LAST:event_updateBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed

        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            Notifications.getInstance().show(Notifications.Type.WARNING, Notifications.Location.TOP_CENTER, "Please Select a Row Before Update!");
        } else {

            String id = String.valueOf(jTable1.getValueAt(selectedRow, 1));

            try {
                MySQL.iud("DELETE FROM `subject_has_student` WHERE `id`='" + id + "'");
                Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully deleted the row.");

                loadData("");
                reset();

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }

    }//GEN-LAST:event_deleteBtnActionPerformed

    private void contentPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contentPanelMouseClicked
        if (evt.getClickCount() == 2) {
            reset();
            registerBtn.setEnabled(true);
            jTable1.setEnabled(true);
        }
    }//GEN-LAST:event_contentPanelMouseClicked

    private void teacherInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherInputActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        student1 s = new student1();
        s.setVisible(true);
        s.setStudentSub(this);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void teacherLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherLabelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherLabelActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel contentPanel;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel name;
    private javax.swing.JPanel navbarPanel;
    private javax.swing.JButton registerBtn;
    private lk.hililk.adyapana.component.HRoundTextField search;
    private javax.swing.JComboBox<String> subjectCombo;
    private lk.hililk.adyapana.component.HRoundTextField teacherInput;
    private lk.hililk.adyapana.component.HRoundTextField teacherLabel;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
