package lk.hililk.adyapana.component;

import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class RoundPasswordField  extends JPasswordField{

    public RoundPasswordField() {
        init();
    }
        
    
    private void init(){
        this.putClientProperty(FlatClientProperties.STYLE, "showRevealButton:true;" +"arc:999;" + "margin:0,10,0,10"); //TOP, LEFT, BOTTOM, RIGHT
    }
}
