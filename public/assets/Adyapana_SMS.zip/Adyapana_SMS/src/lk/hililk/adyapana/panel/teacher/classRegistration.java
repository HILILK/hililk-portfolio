/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package lk.hililk.adyapana.panel.teacher;

import lk.hililk.adyapana.panel.*;
import com.formdev.flatlaf.FlatClientProperties;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import lk.hililk.adyapana.connection.MySQL;
import lk.hililk.adyapana.gui.AdminDashboard;
import lk.hililk.adyapana.gui.TeacherDashboard;
import lk.hililk.adyapana.gui.teacher1;
import raven.toast.Notifications;

/**
 *
 * @author Hirusha
 */
public class classRegistration extends javax.swing.JPanel {

    HashMap<String, String> SubjectMap = new HashMap<>();

    /**
     * Creates new form classRegistration
     */
    public classRegistration() {
        initComponents();
        init();
        loadSubejct();
        loadData("");
        loadName();
    }

    private void loadName() {
        String email = AdminDashboard.aEmail;
        try {
            ResultSet result = MySQL.search("SELECT * FROM `admin` WHERE `email`='" + email + "'");
            if (result.next()) {
                name.setText(result.getString("first_name") + " " + result.getString("last_name"));
                System.out.println(result.getString("first_name") + " " + result.getString("last_name"));
            }
        } catch (SQLException e) {
            AdminDashboard.logger.warning(e.getMessage());
        }
    }

    private void init() {
        search.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Search By Class ID, Teacher's Name, Email or Subject Name");
        search.putClientProperty(FlatClientProperties.TEXT_FIELD_LEADING_ICON, new ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/search (2).png")));
        search.putClientProperty(FlatClientProperties.STYLE, "arc:15;" + "margin:5,20,5,20");
        timeInput.putClientProperty(FlatClientProperties.STYLE, "arc:15;" + "margin:0,10,0,10");
        dateInput.putClientProperty(FlatClientProperties.STYLE, "arc:15;" + "margin:0,10,0,10");
        datePicker1.setEditor(dateInput);
        timePicker1.setEditor(timeInput);
        timeInput.setEditable(false);
        dateInput.setEditable(false);
        teacherLabel.setEditable(false);
        teacherLabel.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Teacher Email");
        teacherLabel.setText(TeacherDashboard.tEmail);
        teacherLabel.setEditable(false);
    }

    private void loadSubejct() {
        try {
            ResultSet result = MySQL.search("SELECT * FROM `subject`");
            Vector<String> subject = new Vector<>();
            subject.add("Select");
            while (result.next()) {
                subject.add(result.getString("name"));
                SubjectMap.put(result.getString("name"), result.getString("id"));
            }
            DefaultComboBoxModel comboBoxModel = new DefaultComboBoxModel(subject);
            this.subjectCombo.setModel(comboBoxModel);

        } catch (SQLException e) {
            AdminDashboard.logger.warning(e.getMessage());
        }
    }

    private void loadData(String searchtxt) {

        if (searchtxt.equals("")) {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `class`"
                        + "INNER JOIN `status` ON `status`.`id`=`class`.`status_id`"
                        + "INNER JOIN `teacher` ON `teacher`.`id`=`class`.`teacher_id`"
                        + "INNER JOIN `subject` ON `subject`.`id`=`class`.`subject_id` WHERE `teacher`.`email`='" + TeacherDashboard.tEmail + "'");
                DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> classList = new Vector();
                    count++;
                    classList.add(String.valueOf(count));
                    classList.add(String.valueOf(result.getString("id")));
                    classList.add(String.valueOf(result.getString("subject.name")));
                    classList.add(String.valueOf(result.getString("teacher.first_name") + " " + result.getString("teacher.last_name")));
                    classList.add(String.valueOf(result.getString("teacher.email")));
                    classList.add(String.valueOf(result.getString("date")));
                    classList.add(String.valueOf(result.getString("time")));
                    classList.add(String.valueOf(result.getString("status.status")));
                    tableModel.addRow(classList);
                }
            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        } else {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `class`"
                        + "INNER JOIN `status` ON `status`.`id`=`class`.`status_id`"
                        + "INNER JOIN `teacher` ON `teacher`.`id`=`class`.`teacher_id`"
                        + "INNER JOIN `subject` ON `subject`.`id`=`class`.`subject_id` WHERE"
                        + " `teacher`.`email`='" + TeacherDashboard.tEmail + "' AND `class`.`id` LIKE '%" + searchtxt + "%' OR"
                        + "`subject`.`name` LIKE '%" + searchtxt + "%' ");
                DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> classList = new Vector();
                    count++;
                    classList.add(String.valueOf(count));
                    classList.add(String.valueOf(result.getString("id")));
                    classList.add(String.valueOf(result.getString("subject.name")));
                    classList.add(String.valueOf(result.getString("teacher.first_name") + " " + result.getString("teacher.last_name")));
                    classList.add(String.valueOf(result.getString("teacher.email")));
                    classList.add(String.valueOf(result.getString("date")));
                    classList.add(String.valueOf(result.getString("time")));
                    classList.add(String.valueOf(result.getString("status.status")));
                    tableModel.addRow(classList);
                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }
    }

    private void reset() {
        subjectCombo.setSelectedItem("Select");
        teacherLabel.setText(TeacherDashboard.tEmail);
        teacherLabel.setEditable(false);
        datePicker1.clearSelectedDate();
        dateInput.setText("--/--/----");
        timePicker1.clearSelectedTime();
        timeInput.setText("--:-- --");
        subjectCombo.grabFocus();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        timePicker1 = new raven.datetime.component.time.TimePicker();
        datePicker1 = new raven.datetime.component.date.DatePicker();
        buttonGroup1 = new javax.swing.ButtonGroup();
        navbarPanel = new javax.swing.JPanel();
        search = new lk.hililk.adyapana.component.HRoundTextField();
        name = new javax.swing.JLabel();
        contentPanel = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        registerBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        subjectCombo = new javax.swing.JComboBox<>();
        timeInput = new javax.swing.JFormattedTextField();
        dateInput = new javax.swing.JFormattedTextField();
        jLabel22 = new javax.swing.JLabel();
        teacherLabel = new lk.hililk.adyapana.component.HRoundTextField();
        activeButton = new javax.swing.JRadioButton();
        deactiveButton = new javax.swing.JRadioButton();

        navbarPanel.setPreferredSize(new java.awt.Dimension(0, 60));

        search.setToolTipText("");
        search.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
        });

        name.setFont(new java.awt.Font("Signika Light", 0, 18)); // NOI18N
        name.setForeground(new java.awt.Color(102, 102, 102));
        name.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        name.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/user.png"))); // NOI18N
        name.setText("  Hirusha Liyanage");

        javax.swing.GroupLayout navbarPanelLayout = new javax.swing.GroupLayout(navbarPanel);
        navbarPanel.setLayout(navbarPanelLayout);
        navbarPanelLayout.setHorizontalGroup(
            navbarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(navbarPanelLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(search, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(23, 23, 23)
                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5))
        );
        navbarPanelLayout.setVerticalGroup(
            navbarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(navbarPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        contentPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contentPanelMouseClicked(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Signika", 0, 18)); // NOI18N
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/subject.png"))); // NOI18N
        jLabel18.setText("Class Registration");
        jLabel18.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel18MouseClicked(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel17.setText("Subject Name");
        jLabel17.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel17MouseClicked(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel20.setText("Teacher's Email");
        jLabel20.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel20MouseClicked(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel19.setText("Date");
        jLabel19.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel21.setText("Time");
        jLabel21.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });

        registerBtn.setBackground(new java.awt.Color(0, 0, 153));
        registerBtn.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        registerBtn.setForeground(new java.awt.Color(255, 255, 255));
        registerBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/tick.png"))); // NOI18N
        registerBtn.setText("Register Class");
        registerBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerBtnActionPerformed(evt);
            }
        });

        updateBtn.setBackground(new java.awt.Color(102, 204, 0));
        updateBtn.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        updateBtn.setForeground(new java.awt.Color(255, 255, 255));
        updateBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/update.png"))); // NOI18N
        updateBtn.setText("Update Class");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        deleteBtn.setBackground(new java.awt.Color(204, 0, 0));
        deleteBtn.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        deleteBtn.setForeground(new java.awt.Color(255, 255, 255));
        deleteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/bin.png"))); // NOI18N
        deleteBtn.setText("Delete Class");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Signika Light", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "Class Id", "Subject Name", "Teacher", "Teacher Email", "Date", "Time", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        subjectCombo.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        subjectCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mathematics", "Science", "Sinhala", "English" }));

        timeInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N

        dateInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N

        jLabel22.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel22.setText("Status");
        jLabel22.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel22MouseClicked(evt);
            }
        });

        teacherLabel.setToolTipText("");
        teacherLabel.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        teacherLabel.setMargin(new java.awt.Insets(0, 50, 0, 10));
        teacherLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherLabelActionPerformed(evt);
            }
        });

        buttonGroup1.add(activeButton);
        activeButton.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        activeButton.setSelected(true);
        activeButton.setText("Active");
        activeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                activeButtonActionPerformed(evt);
            }
        });

        buttonGroup1.add(deactiveButton);
        deactiveButton.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        deactiveButton.setText("Deactive");
        deactiveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deactiveButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout contentPanelLayout = new javax.swing.GroupLayout(contentPanel);
        contentPanel.setLayout(contentPanelLayout);
        contentPanelLayout.setHorizontalGroup(
            contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(contentPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(contentPanelLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(registerBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 359, Short.MAX_VALUE)
                            .addComponent(updateBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(deleteBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(timeInput)
                            .addComponent(subjectCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dateInput)
                            .addComponent(teacherLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(activeButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(deactiveButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(22, 22, 22)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 881, Short.MAX_VALUE)
                .addGap(33, 33, 33))
        );
        contentPanelLayout.setVerticalGroup(
            contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentPanelLayout.createSequentialGroup()
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(contentPanelLayout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(subjectCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(teacherLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dateInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(timeInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(activeButton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deactiveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(registerBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(navbarPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1305, Short.MAX_VALUE)
                .addGap(16, 16, 16))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(navbarPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contentPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    private void jLabel18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel18MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel18MouseClicked

    private void jLabel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel17MouseClicked

    }//GEN-LAST:event_jLabel17MouseClicked

    private void jLabel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel20MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel20MouseClicked

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel19MouseClicked

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel21MouseClicked

    private void registerBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerBtnActionPerformed
        String s = String.valueOf(subjectCombo.getSelectedItem());
        String subject = SubjectMap.get(s);
        String t = teacherLabel.getText();
        LocalDate date = datePicker1.getSelectedDate();
        LocalTime time = timePicker1.getSelectedTime();

        String status = "0";
        if (activeButton.isSelected()) {
            status = "1";
        } else if (deactiveButton.isSelected()) {
            status = "2";
        }

        if (s.equals("Select")) {
            JOptionPane.showMessageDialog(this, "Subject is Required", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (t.isEmpty()) {
            JOptionPane.showMessageDialog(this, "A Teacher is Required", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (date == null) {
            JOptionPane.showMessageDialog(this, "Date is Required", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (time == null) {
            JOptionPane.showMessageDialog(this, "Time is Required", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (status.equals("0")) {

        } else {

            try {

                ResultSet tresult = MySQL.search("SELECT * FROM `teacher` WHERE `email`='" + t + "'");

                if (tresult.next()) {

                    String teacher = tresult.getString("id");

                    ResultSet result = MySQL.search("SELECT * FROM `class` WHERE `date`='" + date + "' AND `time`='" + time + "' AND `teacher_id`='" + teacher + "' AND `subject_id`='" + subject + "' AND `status_id`='" + status + "'");

                    if (result.next()) {
                        Notifications.getInstance().show(Notifications.Type.ERROR, Notifications.Location.TOP_CENTER, "This class is already scheduled.");
                    } else {

                        ResultSet cresult = MySQL.search("SELECT * FROM `teacher_has_subject` WHERE `teacher_id`='" + teacher + "' AND `subject_id`='" + subject + "' ");

                        if (cresult.next()) {
                            MySQL.iud("INSERT INTO `class` (`date`,`time`,`teacher_id`,`subject_id`,`status_id`) VALUES ('" + date + "','" + time + "','" + teacher + "','" + subject + "','" + status + "')");
                            Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully added the Class.");
                            loadData("");
                            reset();
                        } else {
                            Notifications.getInstance().show(Notifications.Type.ERROR, Notifications.Location.TOP_CENTER, "This subject is not a subject of this teacher.");
                        }
                    }

                }

            } catch (SQLException e) {
                TeacherDashboard.logger1.warning(e.getMessage());
            }

        }

    }//GEN-LAST:event_registerBtnActionPerformed

    private void contentPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contentPanelMouseClicked
        if (evt.getClickCount() == 2) {
            reset();
            registerBtn.setEnabled(true);
            jTable1.setEnabled(true);
        }
    }//GEN-LAST:event_contentPanelMouseClicked

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            Notifications.getInstance().show(Notifications.Type.WARNING, Notifications.Location.TOP_CENTER, "Please Select a Row Before Update!");
        } else {

            String id = String.valueOf(jTable1.getValueAt(selectedRow, 1));

            try {

                MySQL.iud("DELETE FROM `class` WHERE `id`='" + id + "'");
                Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully deleted the Class.");
                loadData("");
                reset();

            } catch (SQLException e) {
                TeacherDashboard.logger1.warning(e.getMessage());
            }
        }


    }//GEN-LAST:event_deleteBtnActionPerformed

    private void jLabel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel22MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel22MouseClicked

    private void teacherLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherLabelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherLabelActionPerformed

    private void activeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_activeButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_activeButtonActionPerformed

    private void deactiveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deactiveButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deactiveButtonActionPerformed

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
        String searctxt = search.getText();
        loadData(searctxt);
    }//GEN-LAST:event_searchKeyReleased

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if (evt.getClickCount() == 2) {

            int selectedRow = jTable1.getSelectedRow();
            String teacher = String.valueOf(jTable1.getValueAt(selectedRow, 4));
            String subject = String.valueOf(jTable1.getValueAt(selectedRow, 2));
            String status = String.valueOf(jTable1.getValueAt(selectedRow, 7));
            LocalDate date = LocalDate.parse((CharSequence) jTable1.getValueAt(selectedRow, 5));
            LocalTime time = LocalTime.parse((CharSequence) jTable1.getValueAt(selectedRow, 6));

            subjectCombo.setSelectedItem(subject);
            if (status.equals("Active")) {
                activeButton.setSelected(true);
                deactiveButton.setSelected(false);
            } else if (status.equals("Deactive")) {
                activeButton.setSelected(false);
                deactiveButton.setSelected(true);
            }
            datePicker1.setSelectedDate(date);
            timePicker1.setSelectedTime(time);
            registerBtn.setEnabled(false);
//            jTable1.setEnabled(false);

            try {

                ResultSet result = MySQL.search("SELECT * FROM `teacher` WHERE `email`='" + teacher + "'");

                if (result.next()) {
                    teacherLabel.setText(teacher);

                }

            } catch (SQLException e) {
                TeacherDashboard.logger1.warning(e.getMessage());
            }

        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            Notifications.getInstance().show(Notifications.Type.WARNING, Notifications.Location.TOP_CENTER, "Please Select a Row Before Update!");
        } else {

            String s = String.valueOf(subjectCombo.getSelectedItem());
            String subject = SubjectMap.get(s);
            String t = teacherLabel.getText();
            LocalDate date = datePicker1.getSelectedDate();
            LocalTime time = timePicker1.getSelectedTime();
            String id = String.valueOf(jTable1.getValueAt(selectedRow, 1));

            String status = "0";
            if (activeButton.isSelected()) {
                status = "1";
            } else if (deactiveButton.isSelected()) {
                status = "2";
            }

            if (s.equals("Select")) {
                JOptionPane.showMessageDialog(this, "Subject is Required", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (t.isEmpty()) {
                JOptionPane.showMessageDialog(this, "A Teacher is Required", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (date == null) {
                JOptionPane.showMessageDialog(this, "Date is Required", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (time == null) {
                JOptionPane.showMessageDialog(this, "Time is Required", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (status.equals("0")) {

            } else {

                try {

                    ResultSet tresult = MySQL.search("SELECT * FROM `teacher` WHERE `email`='" + t + "'");

                    if (tresult.next()) {

                        String teacher = tresult.getString("id");

                        ResultSet cresult = MySQL.search("SELECT * FROM `teacher_has_subject` WHERE `teacher_id`='" + teacher + "' AND `subject_id`='" + subject + "' ");

                        if (cresult.next()) {
                            MySQL.iud("UPDATE `class` SET `date`='" + date + "', `time`='" + time + "', `teacher_id`='" + teacher + "', `subject_id`='" + subject + "', `status_id`='" + status + "' WHERE `id`='" + id + "'");
                            Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully updated the Class.");
                            loadData("");
                            reset();
                        } else {
                            Notifications.getInstance().show(Notifications.Type.ERROR, Notifications.Location.TOP_CENTER, "This subject is not a subject of this teacher.");
                        }

                    }

                } catch (SQLException e) {
                    TeacherDashboard.logger1.warning(e.getMessage());
                }
            }

        }


    }//GEN-LAST:event_updateBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton activeButton;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JPanel contentPanel;
    private javax.swing.JFormattedTextField dateInput;
    private raven.datetime.component.date.DatePicker datePicker1;
    private javax.swing.JRadioButton deactiveButton;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel name;
    private javax.swing.JPanel navbarPanel;
    private javax.swing.JButton registerBtn;
    private lk.hililk.adyapana.component.HRoundTextField search;
    private javax.swing.JComboBox<String> subjectCombo;
    private lk.hililk.adyapana.component.HRoundTextField teacherLabel;
    private javax.swing.JFormattedTextField timeInput;
    private raven.datetime.component.time.TimePicker timePicker1;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
