/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package lk.hililk.adyapana.panel;

import com.formdev.flatlaf.FlatClientProperties;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import lk.hililk.adyapana.connection.MySQL;
import lk.hililk.adyapana.gui.AdminDashboard;
import lk.hililk.adyapana.gui.Splash;
import raven.toast.Notifications;

/**
 *
 * @author Hirusha
 */
public class studentRegistration extends javax.swing.JPanel {

    /**
     * Creates new form studentRegistration
     */
    private AdminDashboard adminDashboard;

    public studentRegistration() {
        initComponents();
        init();
        loadData("");
        loadName();
    }
    
     private void loadName(){
        String email = AdminDashboard.aEmail;
        try {
            ResultSet result = MySQL.search("SELECT * FROM `admin` WHERE `email`='"+email+"'");
            if(result.next()){
                name.setText(result.getString("first_name")+" "+result.getString("last_name"));
            }
        } catch (SQLException e) {
            AdminDashboard.logger.warning(e.getMessage());
        }
    }

    public studentRegistration(AdminDashboard adminDashboard) {
        this();
        this.adminDashboard = adminDashboard;
        Notifications.getInstance().setJFrame(adminDashboard);
    }

    private void init() {
        search.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Search By Student's Name or Email");
        search.putClientProperty(FlatClientProperties.TEXT_FIELD_LEADING_ICON, new ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/search (2).png")));
        search.putClientProperty(FlatClientProperties.STYLE, "arc:15;" + "margin:5,20,5,20");
        dobInput.putClientProperty(FlatClientProperties.STYLE, "arc:15;" + "margin:0,10,0,10");
        dobInput.setEditable(false);
        datePicker1.now();
        datePicker1.setEditor(dobInput);
    }

    private void loadData(String searchtxt) {

        if (searchtxt.equals("")) {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `student`");
                DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> studentList = new Vector();
                    count++;
                    studentList.add(String.valueOf(count));
                    studentList.add(String.valueOf(result.getString("id")));
                    studentList.add(String.valueOf(result.getString("first_name")));
                    studentList.add(String.valueOf(result.getString("last_name")));
                    studentList.add(String.valueOf(result.getString("email")));
                    studentList.add(String.valueOf(result.getString("mobile")));
                    studentList.add(String.valueOf(result.getString("address")));
                    studentList.add(String.valueOf(result.getString("dob")));
                    studentList.add(String.valueOf(result.getString("registered_date")));
                    tableModel.addRow(studentList);
                }
            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        } else {
            try {

                ResultSet result = MySQL.search("SELECT * FROM `student` WHERE `first_name` LIKE '%" + searchtxt + "%' OR `last_name` LIKE '%" + searchtxt + "%' OR `email` LIKE '%" + searchtxt + "%'");
                DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
                tableModel.setRowCount(0);
                int count = 0;

                while (result.next()) {
                    Vector<String> studentList = new Vector();
                    count++;
                    studentList.add(String.valueOf(count));
                    studentList.add(String.valueOf(result.getString("id")));
                    studentList.add(String.valueOf(result.getString("first_name")));
                    studentList.add(String.valueOf(result.getString("last_name")));
                    studentList.add(String.valueOf(result.getString("email")));
                    studentList.add(String.valueOf(result.getString("mobile")));
                    studentList.add(String.valueOf(result.getString("address")));
                    studentList.add(String.valueOf(result.getString("dob")));
                    studentList.add(String.valueOf(result.getString("registered_date")));
                    tableModel.addRow(studentList);
                }
            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }
    }

    private void reset() {
        firstNameInput.setText("");
        lastNameInput.setText("");
        emailInput.setText("");
        mobileInput.setText("");
        addressInput.setText("");
        datePicker1.clearSelectedDate();
        dobInput.setText("--/--/----");
        firstNameInput.requestFocus();
        registerBtn.setEnabled(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        datePicker1 = new raven.datetime.component.date.DatePicker();
        navbarPanel = new javax.swing.JPanel();
        search = new lk.hililk.adyapana.component.HRoundTextField();
        name = new javax.swing.JLabel();
        contentPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        firstNameInput = new lk.hililk.adyapana.component.HRoundTextField();
        jLabel9 = new javax.swing.JLabel();
        lastNameInput = new lk.hililk.adyapana.component.HRoundTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        registerBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        dobInput = new javax.swing.JFormattedTextField();
        jLabel15 = new javax.swing.JLabel();
        mobileInput = new lk.hililk.adyapana.component.HRoundTextField();
        emailInput = new lk.hililk.adyapana.component.HRoundTextField();
        addressInput = new lk.hililk.adyapana.component.HRoundTextField();

        setPreferredSize(new java.awt.Dimension(1500, 807));

        navbarPanel.setPreferredSize(new java.awt.Dimension(0, 60));

        search.setToolTipText("");
        search.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
        });

        name.setFont(new java.awt.Font("Signika Light", 0, 18)); // NOI18N
        name.setForeground(new java.awt.Color(102, 102, 102));
        name.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        name.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/user.png"))); // NOI18N
        name.setText("  Hirusha Liyanage");

        javax.swing.GroupLayout navbarPanelLayout = new javax.swing.GroupLayout(navbarPanel);
        navbarPanel.setLayout(navbarPanelLayout);
        navbarPanelLayout.setHorizontalGroup(
            navbarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(navbarPanelLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(search, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(23, 23, 23)
                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5))
        );
        navbarPanelLayout.setVerticalGroup(
            navbarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(navbarPanelLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        contentPanel.setPreferredSize(new java.awt.Dimension(0, 100));
        contentPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contentPanelMouseClicked(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Signika Light", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#", "Student_id", "First Name", "Last Name", "Email", "Mobile", "Address", "Date of Birth", "Registered Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel7.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel7.setText("First Name");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Signika", 0, 18)); // NOI18N
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/student.png"))); // NOI18N
        jLabel8.setText(" Student Registration");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        firstNameInput.setToolTipText("");
        firstNameInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        firstNameInput.setMargin(new java.awt.Insets(0, 50, 0, 10));
        firstNameInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstNameInputActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel9.setText("Last Name");
        jLabel9.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        lastNameInput.setToolTipText("");
        lastNameInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        lastNameInput.setMargin(new java.awt.Insets(0, 50, 0, 10));
        lastNameInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastNameInputActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel10.setText("Email Address");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel12.setText("Address");
        jLabel12.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel13.setText("Date of Birth");
        jLabel13.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });

        registerBtn.setBackground(new java.awt.Color(0, 0, 153));
        registerBtn.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        registerBtn.setForeground(new java.awt.Color(255, 255, 255));
        registerBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/tick.png"))); // NOI18N
        registerBtn.setText("Register Student");
        registerBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerBtnActionPerformed(evt);
            }
        });

        updateBtn.setBackground(new java.awt.Color(102, 204, 0));
        updateBtn.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        updateBtn.setForeground(new java.awt.Color(255, 255, 255));
        updateBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/update.png"))); // NOI18N
        updateBtn.setText("Update Student");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        deleteBtn.setBackground(new java.awt.Color(204, 0, 0));
        deleteBtn.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        deleteBtn.setForeground(new java.awt.Color(255, 255, 255));
        deleteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lk/hililk/adyapana/img/bin.png"))); // NOI18N
        deleteBtn.setText("Delete Student");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        dobInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        dobInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dobInputActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Signika Light", 0, 17)); // NOI18N
        jLabel15.setText("Mobile");
        jLabel15.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });

        mobileInput.setToolTipText("");
        mobileInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        mobileInput.setMargin(new java.awt.Insets(0, 50, 0, 10));
        mobileInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mobileInputActionPerformed(evt);
            }
        });

        emailInput.setToolTipText("");
        emailInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        emailInput.setMargin(new java.awt.Insets(0, 50, 0, 10));

        addressInput.setToolTipText("");
        addressInput.setFont(new java.awt.Font("Signika Light", 0, 16)); // NOI18N
        addressInput.setMargin(new java.awt.Insets(0, 50, 0, 10));

        javax.swing.GroupLayout contentPanelLayout = new javax.swing.GroupLayout(contentPanel);
        contentPanel.setLayout(contentPanelLayout);
        contentPanelLayout.setHorizontalGroup(
            contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentPanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lastNameInput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(firstNameInput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(registerBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dobInput)
                    .addComponent(updateBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(deleteBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(contentPanelLayout.createSequentialGroup()
                        .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 275, Short.MAX_VALUE))
                    .addComponent(mobileInput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(emailInput, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addressInput, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 929, Short.MAX_VALUE)
                .addGap(27, 27, 27))
            .addComponent(jSeparator2)
        );
        contentPanelLayout.setVerticalGroup(
            contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentPanelLayout.createSequentialGroup()
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(contentPanelLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(firstNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lastNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(emailInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12)
                        .addGap(12, 12, 12)
                        .addComponent(addressInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mobileInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dobInput, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19)
                        .addComponent(registerBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1))
                .addContainerGap(75, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(navbarPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1500, Short.MAX_VALUE)
            .addComponent(contentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1500, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(navbarPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 741, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked

    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel8MouseClicked

    private void firstNameInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstNameInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_firstNameInputActionPerformed

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel9MouseClicked

    private void lastNameInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastNameInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lastNameInputActionPerformed

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel13MouseClicked

    private void contentPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contentPanelMouseClicked
        if (evt.getClickCount() == 2) {
            reset();
            registerBtn.setEnabled(true);
            jTable1.setEnabled(true);
        }
    }//GEN-LAST:event_contentPanelMouseClicked

    private void dobInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dobInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dobInputActionPerformed

    private void registerBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerBtnActionPerformed

        String fname = firstNameInput.getText();
        String lname = lastNameInput.getText();
        String email = emailInput.getText();
        String mobile = mobileInput.getText();
        String address = addressInput.getText();
        LocalDate dob = datePicker1.getSelectedDate();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();

        if (fname.isEmpty()) {
            JOptionPane.showMessageDialog(this, "First Name is Required", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (lname.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Last Name is Required", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Email is Required", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (!email.matches("^[a-zA-Z0-9_!#$%&amp;'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$")) {
            JOptionPane.showMessageDialog(this, "Invalid Email", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Address is Required", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (mobile.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mobile No is Required", "Warning", JOptionPane.WARNING_MESSAGE);

        } else if (!mobile.matches("^(0{1})(7{1})([0|1|2|4|5|6|7|8]{1})([0-9]{7})")) {
            JOptionPane.showMessageDialog(this, "Invalid Mobile No", "Warning", JOptionPane.WARNING_MESSAGE);

        } else {

            try {

                ResultSet result = MySQL.search("SELECT * FROM `student` WHERE `email`='" + email + "'");

                if (result.next()) {
                    Notifications.getInstance().show(Notifications.Type.ERROR, Notifications.Location.TOP_CENTER, "Student with the same name and email is already exsists.");
                } else {
                    MySQL.iud("INSERT INTO `student` (`first_name`,`last_name`,`email`,`mobile`,`address`,`dob`,`registered_date`) VALUES ('" + fname + "','" + lname + "','" + email + "','" + mobile + "','" + address + "','" + dob + "','" + now + "')");
                    Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully added the teacher.");
                    
                    loadData("");
                    reset();
                }

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }
        }

    }//GEN-LAST:event_registerBtnActionPerformed

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel15MouseClicked

    private void mobileInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mobileInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mobileInputActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed

        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            Notifications.getInstance().show(Notifications.Type.WARNING, Notifications.Location.TOP_CENTER, "Please Select a Row Before Update!");
        } else {

            String id = String.valueOf(jTable1.getValueAt(selectedRow, 1));
            String fname = firstNameInput.getText();
            String lname = lastNameInput.getText();
            String email = emailInput.getText();
            String mobile = mobileInput.getText();
            String address = addressInput.getText();
            LocalDate dob = datePicker1.getSelectedDate();
            
            if (fname.isEmpty()) {
                JOptionPane.showMessageDialog(this, "First Name is Required", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (lname.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Last Name is Required", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (email.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Email is Required", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (!email.matches("^[a-zA-Z0-9_!#$%&amp;'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$")) {
                JOptionPane.showMessageDialog(this, "Invalid Email", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (address.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Address is Required", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (mobile.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Mobile No is Required", "Warning", JOptionPane.WARNING_MESSAGE);

            } else if (!mobile.matches("^(0{1})(7{1})([0|1|2|4|5|6|7|8]{1})([0-9]{7})")) {
                JOptionPane.showMessageDialog(this, "Invalid Mobile No", "Warning", JOptionPane.WARNING_MESSAGE);

            } else {

                try {
                    MySQL.iud("UPDATE `student` SET `first_name`='" + fname + "', `last_name`='" + lname + "', `email`='" + email + "', `mobile`='" + mobile + "', `address`='" + address + "', `dob`='" + dob + "' WHERE `id`='" + id + "'");
                    Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully updated the student.");

                    loadData("");
                    reset();

                } catch (SQLException e) {
                    AdminDashboard.logger.warning(e.getMessage());
                }

            }

        }
    }//GEN-LAST:event_updateBtnActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if (evt.getClickCount() == 2) {

            int selectedRow = jTable1.getSelectedRow();

            String fname = String.valueOf(jTable1.getValueAt(selectedRow, 2));
            String lname = String.valueOf(jTable1.getValueAt(selectedRow, 3));
            String email = String.valueOf(jTable1.getValueAt(selectedRow, 4));
            String mobile = String.valueOf(jTable1.getValueAt(selectedRow, 5));
            String address = String.valueOf(jTable1.getValueAt(selectedRow, 6));
            LocalDate dob = LocalDate.parse((CharSequence) jTable1.getValueAt(selectedRow, 7));

            firstNameInput.setText(fname);
            lastNameInput.setText(lname);
            emailInput.setText(email);
            mobileInput.setText(mobile);
            addressInput.setText(address);
            datePicker1.now();
            datePicker1.setSelectedDate(dob);
            registerBtn.setEnabled(false);

        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            Notifications.getInstance().show(Notifications.Type.WARNING, Notifications.Location.TOP_CENTER, "Please Select a Row Before Update!");
        } else {

            String id = String.valueOf(jTable1.getValueAt(selectedRow, 1));

            try {
                MySQL.iud("DELETE FROM `student` WHERE `id`='" + id + "'");
                 Notifications.getInstance().show(Notifications.Type.SUCCESS, Notifications.Location.TOP_CENTER, "Successfully deleted the student.");
                 
                loadData("");
                reset();

            } catch (SQLException e) {
                AdminDashboard.logger.warning(e.getMessage());
            }

        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
        String txt = search.getText();
        loadData(txt);
    }//GEN-LAST:event_searchKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private lk.hililk.adyapana.component.HRoundTextField addressInput;
    private javax.swing.JPanel contentPanel;
    private raven.datetime.component.date.DatePicker datePicker1;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JFormattedTextField dobInput;
    private lk.hililk.adyapana.component.HRoundTextField emailInput;
    private lk.hililk.adyapana.component.HRoundTextField firstNameInput;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTable1;
    private lk.hililk.adyapana.component.HRoundTextField lastNameInput;
    private lk.hililk.adyapana.component.HRoundTextField mobileInput;
    private javax.swing.JLabel name;
    private javax.swing.JPanel navbarPanel;
    private javax.swing.JButton registerBtn;
    private lk.hililk.adyapana.component.HRoundTextField search;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
