package lk.hililk.adyapana.component;

import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class HRoundPasswordField extends JPasswordField {

    public HRoundPasswordField() {
        init();
    }

    private void init() {
//        this.putClientProperty(FlatClientProperties.STYLE, "showRevealButton:true");
        this.putClientProperty(FlatClientProperties.STYLE, "showRevealButton:true;" + "arc:15;" + "margin:0,10,0,10"); //TOP, LEFT, BOTTOM, RIGHT
    }
}
