package lk.hililk.adyapana.component;

import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.JTextArea;

public class RoundTextArea extends JTextArea {

    public RoundTextArea() {
        init();
    }

    private void init() {
//        this.putClientProperty(FlatClientProperties.STYLE, "showRevealButton:true");
        this.putClientProperty(FlatClientProperties.STYLE, "round:15;" + "margin:0,10,0,10"); //TOP, LEFT, BOTTOM, RIGHT
    }

}
