package lk.hililk.adyapana.connection;

import com.mysql.cj.jdbc.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import lk.hililk.adyapana.gui.AdminDashboard;
import lk.hililk.adyapana.gui.Splash;

public class MySQL {

    public static Connection connection;

    private static final String DatabaseName = "adyapana_db";
    private static final String userName = "root";
    private static final String password = "Mysql1234$";

    public static Connection getConnection() {
        try {
            if (connection == null) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + DatabaseName, userName, password);
            }
            return connection;
        } catch (SQLException | ClassNotFoundException ex) {
//            throw new ExceptionInInitializerError("Mysql Connection Failed!");
                AdminDashboard.logger.warning(ex.getMessage());
        }
        return null;
    }
    
    public static void iud(String query) throws SQLException {
       getConnection().createStatement().executeUpdate(query);
    }
    
    public static ResultSet search(String query) throws SQLException{
           ResultSet result =  getConnection().createStatement().executeQuery(query);
           return result;
    }
    
}
